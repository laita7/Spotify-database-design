
from django.urls import path
from . import views

urlpatterns = [
    path('', views.inicio, name='inicio'),  # <-- Esta línea agrega la ruta raíz
    path('popularidad_artistas/', views.popularidad_artistas, name='popularidad_artistas'),
    path('popularidad_año/', views.popularidad_año, name='popularidad_año'),
    path('canciones_decadas/', views.canciones_decadas, name='canciones_decadas'),
    path('duracion_año/', views.duracion_año, name='duracion_año'),
    path('individual_colaboracion/', views.individual_colaboracion, name='individual_colaboracion'),
    path('duracion_vs_popularidad/', views.duracion_vs_popularidad, name='duracion_vs_popularidad'),
    path('acerca_bd/', views.acerca_bd, name='acerca_bd'),
]