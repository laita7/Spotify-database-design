from .sqlUtil import exQuery
from .sqlUtil import exQueryDataframe
import pandas as pd
import matplotlib.pyplot as plt
import datetime
import numpy as np
import matplotlib
matplotlib.use('Agg')

def f_popularidad_artistas():
    query = """
        SELECT ar.Nombre_Art, AVG(c.Popularidad) AS Promedio_Popularidad, COUNT(c.ID_Cancion) AS Num_Canciones
        FROM artista ar
        JOIN cancion_artista ca ON ar.ID_Artista = ca.ID_Artista
        JOIN cancion c ON ca.ID_Cancion = c.ID_Cancion
        GROUP BY ar.ID_Artista
        HAVING COUNT(c.ID_Cancion) >= 3
        ORDER BY Promedio_Popularidad DESC
        LIMIT 15;
    """
    df = exQueryDataframe(query)
    print(df)
    print(df.columns)
    df = df[(df['Promedio_Popularidad'] >= 80) & (df['Promedio_Popularidad'] <= 95)]

    plt.style.use('seaborn-v0_8-darkgrid')
    plt.figure(figsize=(12, 6))

    # Resaltar el artista más popular
    idx_max = df['Promedio_Popularidad'].idxmax()
    colors = ['#0077b6' if i != idx_max else '#ffb703' for i in range(len(df))]

    # Graficar puntos
    plt.scatter(df['Nombre_Art'], df['Promedio_Popularidad'], color=colors, s=140, edgecolor='black', alpha=0.9, zorder=2)

    # Mostrar valores encima de cada punto
    for i, row in df.iterrows():
        plt.text(row['Nombre_Art'], row['Promedio_Popularidad'] + 0.5, f"{row['Promedio_Popularidad']:.1f}",
                 ha='center', va='bottom', fontsize=11, fontweight='bold')

    plt.xlabel('Artista', fontsize=14, fontweight='bold')
    plt.ylabel('Popularidad Promedio', fontsize=14, fontweight='bold')
    plt.title('Top Artistas por Popularidad Promedio (80-95, mínimo 3 canciones)', fontsize=16, fontweight='bold')
    plt.ylim(80, 95)
    plt.xticks(rotation=45, ha='right', fontsize=12)
    plt.yticks(fontsize=12)
    plt.tight_layout()
    plt.savefig('static/popularidad_artistas.png', bbox_inches='tight', dpi=120)
    plt.close()

def f_popularidad_año():
    query = """
        SELECT YEAR(a.Fecha) AS Año, AVG(c.Popularidad) AS Popularidad_Promedio
        FROM cancion c
        JOIN album a ON c.ID_Album = a.ID_Album
        GROUP BY Año
        ORDER BY Año ASC;
    """
    df = exQueryDataframe(query)
    plt.style.use('seaborn-v0_8-darkgrid')
    plt.figure(figsize=(12, 6))  # Ancho 7, alto 4 (puedes ajustar estos valores)

    # Encontrar el año más popular
    idx_max = df['Popularidad_Promedio'].idxmax()
    año_max = df.loc[idx_max, 'Año']

    # Colores: todos iguales menos el máximo
    colors = ['#4f8bc9' if año != año_max else '#e63946' for año in df['Año']]

    # Graficar líneas y puntos
    plt.plot(df['Año'], df['Popularidad_Promedio'], color='#457b9d', linewidth=2.5, zorder=1)
    plt.scatter(df['Año'], df['Popularidad_Promedio'], color=colors, s=120, edgecolor='black', zorder=2)

    # Ejes y título
    plt.xlabel('Año', fontsize=14, fontweight='bold')
    plt.ylabel('Popularidad Promedio', fontsize=14, fontweight='bold')
    plt.title('Evolución de la Popularidad Promedio de las Canciones por Año', fontsize=17, fontweight='bold')
    plt.grid(True, linestyle='--', alpha=0.5)
    plt.xticks(fontsize=12, rotation=45)
    plt.yticks(fontsize=12)

    plt.tight_layout()
    plt.savefig('static/popularidad_año_v2.png', bbox_inches='tight', dpi=120)
    plt.close()
    
def f_canciones_decadas():
    query = "SELECT CONCAT(FLOOR(YEAR(a.Fecha)/10)*10, 's') AS Decada, COUNT(*) AS Numero_Canciones FROM cancion c JOIN album a ON c.ID_Album = a.ID_Album GROUP BY Decada ORDER BY Decada ASC;"
    df = exQueryDataframe(query)
    plt.style.use('seaborn-v0_8-darkgrid')
    plt.figure(figsize=(9,5))
    bars = plt.bar(df['Decada'], df['Numero_Canciones'], color=plt.cm.viridis(np.linspace(0.2, 0.8, len(df))))
    plt.xlabel('Década', fontsize=13, fontweight='bold')
    plt.ylabel('Número de Canciones', fontsize=13, fontweight='bold')
    plt.title('Número de Canciones Publicadas por Década', fontsize=15, fontweight='bold')
    plt.xticks(fontsize=11)
    plt.yticks(fontsize=11)
    plt.tight_layout()
    # Mostrar valores encima de cada barra
    for bar in bars:
        plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 1, int(bar.get_height()), 
                 ha='center', va='bottom', fontsize=11, fontweight='bold')
    plt.savefig('static/canciones_decadas.png', bbox_inches='tight', dpi=120)
    plt.close()


def f_duracion_año():
    query = "SELECT YEAR(a.Fecha) AS Año, AVG(c.Duracion) AS Duracion_Promedio FROM cancion c JOIN album a ON c.ID_Album = a.ID_Album GROUP BY Año ORDER BY Año ASC;"
    df = exQueryDataframe(query)
    df = df.sort_values('Año')  # Asegura que los años estén ordenados de menor a mayor
    plt.style.use('seaborn-v0_8-darkgrid')
    plt.figure(figsize=(10, 5))

    plt.plot(df['Año'], df['Duracion_Promedio'], color='#1DB954', linewidth=2.5, marker='o')
    plt.xlabel('Año', fontsize=13, fontweight='bold')
    plt.ylabel('Duración Promedio (segundos)', fontsize=13, fontweight='bold')
    plt.title('Evolución de la Duración Promedio de las Canciones por Año', fontsize=15, fontweight='bold')
    plt.grid(True, linestyle='--', alpha=0.5)
    plt.xticks(fontsize=11, rotation=45)
    plt.yticks(fontsize=11)
    plt.tight_layout()
    plt.savefig('static/duracion_anio.png', bbox_inches='tight', dpi=120)
    plt.close()

def f_individual_colaboracion():
    query = """
        SELECT Tipo, AVG(Popularidad_Promedio) AS Media_Popularidad
        FROM (
            SELECT c.ID_Cancion,
                   CASE WHEN COUNT(ca.ID_Artista) = 1 THEN 'Individual' ELSE 'Colaboración' END AS Tipo,
                   c.Popularidad AS Popularidad_Promedio
            FROM cancion c
            JOIN cancion_artista ca ON c.ID_Cancion = ca.ID_Cancion
            GROUP BY c.ID_Cancion
        ) AS Subconsulta
        GROUP BY Tipo;
    """
    df = exQueryDataframe(query)
    plt.style.use('seaborn-v0_8-darkgrid')
    plt.figure(figsize=(7,5))
    colors = ['#457b9d', '#ffb703']
    bars = plt.bar(df['Tipo'], df['Media_Popularidad'], color=colors, edgecolor='black', width=0.5)
    plt.xlabel('Tipo de Canción', fontsize=13, fontweight='bold')
    plt.ylabel('Popularidad Promedio', fontsize=13, fontweight='bold')
    plt.title('Popularidad Promedio: Individual vs Colaboración', fontsize=15, fontweight='bold')
    plt.ylim(0, 100)
    plt.xticks(fontsize=12)
    plt.yticks(fontsize=12)
    plt.tight_layout()
    # Mostrar valores encima de cada barra
    for bar in bars:
        plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 1, f"{bar.get_height():.1f}",
                 ha='center', va='bottom', fontsize=12, fontweight='bold')
    plt.savefig('static/individual_colaboracion.png', bbox_inches='tight', dpi=120)
    plt.close()

def f_duracion_vs_popularidad():
    query = """
        SELECT c.Duracion, c.Popularidad
        FROM cancion c
        WHERE c.Duracion IS NOT NULL AND c.Popularidad IS NOT NULL
    """
    df = exQueryDataframe(query)
    plt.style.use('seaborn-v0_8-darkgrid')
    plt.figure(figsize=(8,5))

    # Limitar valores extremos para mejor visualización
    df = df[(df['Duracion'] < 600) & (df['Popularidad'] >= 0) & (df['Popularidad'] <= 100)]

    # Scatter plot
    plt.scatter(df['Duracion'], df['Popularidad'], alpha=0.5, color='#0077b6', edgecolor='black', s=40)

    # Línea de tendencia (regresión lineal)
    if len(df) > 1:
        z = np.polyfit(df['Duracion'], df['Popularidad'], 1)
        p = np.poly1d(z)
        plt.plot(df['Duracion'], p(df['Duracion']), color='#ffb703', linewidth=2, label='Tendencia')

    plt.xlabel('Duración de la Canción (segundos)', fontsize=13, fontweight='bold')
    plt.ylabel('Popularidad', fontsize=13, fontweight='bold')
    plt.title('¿Las canciones más largas son más populares?', fontsize=15, fontweight='bold')
    plt.grid(True, linestyle='--', alpha=0.5)
    plt.legend()
    plt.tight_layout()
    plt.savefig('static/duracion_vs_popularidad.png', bbox_inches='tight', dpi=120)
    plt.close()
