from django import forms

def anios():
    import datetime
    current_year = datetime.datetime.now().year
    return [(str(year), str(year)) for year in range(current_year - 10, current_year + 1)]

class ConsultaEuriborForm(forms.Form):
    nombre=forms.CharField(label='Nombre: ',max_length=40)
    mes = forms.IntegerField(label='Mes: ',max_value=12, min_value=1)
    anio = forms.ChoiceField(label='Año: ', choices=anios())
    euribor=forms.Textarea()
