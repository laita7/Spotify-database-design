from audioop import reverse
from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from .forms import ConsultaEuriborForm
from .funciones import f_popularidad_artistas
from .funciones import f_popularidad_año
from .funciones import f_canciones_decadas
from .funciones import f_duracion_año
from .funciones import f_individual_colaboracion
from .funciones import f_duracion_vs_popularidad
from django.shortcuts import render
from django.utils import timezone

def inicio(request):
    return render(request, 'inicio.html')
# Create your views here.

def index(request):
    return render(request, 'index.html')

def popularidad_artistas(request):
    f_popularidad_artistas()
    return render(request, 'popularidad_artistas.html', {'now': timezone.now()})
from django.utils import timezone

def popularidad_año(request):
    f_popularidad_año()
    return render(request, 'popularidad_año.html', {'now': timezone.now()})

def canciones_decadas(request):
    f_canciones_decadas()
    return render(request, 'canciones_decadas.html', {'now': timezone.now()})

def duracion_año(request):
    f_duracion_año()
    return render(request, 'duracion_año.html', {'now': timezone.now()})

def individual_colaboracion(request):
    f_individual_colaboracion()
    return render(request, 'individual_colaboracion.html', {'now': timezone.now()})  

def duracion_vs_popularidad(request):
    f_duracion_vs_popularidad()
    return render(request, 'duracion_vs_popularidad.html', {'now': timezone.now()})

def acerca_bd(request):
    return render(request, 'acerca_bd.html')

def inicio(request):
    # ... tu lógica ...
    return render(request, 'inicio.html', {'mostrar_footer_img': True})
